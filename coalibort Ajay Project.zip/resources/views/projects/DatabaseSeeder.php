<?php

namespace Database\Seeders;

use App\Models\Project;
use App\Models\Task;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Create sample projects
        $project1 = Project::create([
            'name' => 'Website Redesign',
            'description' => 'Complete overhaul of company website'
        ]);

        $project2 = Project::create([
            'name' => 'Mobile App Development',
            'description' => 'New iOS and Android application'
        ]);

        $project3 = Project::create([
            'name' => 'Marketing Campaign',
            'description' => 'Q4 marketing initiatives'
        ]);

        // Create sample tasks for project 1
        Task::create(['name' => 'Design homepage mockup', 'priority' => 1, 'project_id' => $project1->id]);
        Task::create(['name' => 'Develop responsive layout', 'priority' => 2, 'project_id' => $project1->id]);
        Task::create(['name' => 'Implement contact form', 'priority' => 3, 'project_id' => $project1->id]);

        // Create sample tasks for project 2
        Task::create(['name' => 'Set up development environment', 'priority' => 1, 'project_id' => $project2->id]);
        Task::create(['name' => 'Create user authentication', 'priority' => 2, 'project_id' => $project2->id]);
        Task::create(['name' => 'Design app icon', 'priority' => 3, 'project_id' => $project2->id]);

        // Create sample tasks for project 3
        Task::create(['name' => 'Create social media content', 'priority' => 1, 'project_id' => $project3->id]);
        Task::create(['name' => 'Schedule email campaign', 'priority' => 2, 'project_id' => $project3->id]);
    }
}

